TODO
====

1) remove dependency on ofxOpenCv - look into this method - [https://github.com/danomatika/ofxAppUtils/blob/master/src/ofxQuadWarper.cpp](https://github.com/danomatika/ofxAppUtils/blob/master/src/ofxQuadWarper.cpp)