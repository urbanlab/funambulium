#pragma once

#include "ofxSimpleGuiControl.h"

#include "ofxSimpleGuiSliderBase.h"


class ofxSimpleGuiSliderFloat : public ofxSimpleGuiSliderBase<float> {
	
public:
	ofxSimpleGuiSliderFloat(string name, float &value, float min, float max, std::string oscName) : ofxSimpleGuiSliderBase<float>(name, value, min, max, oscName) {
		controlType = "SliderFloat";
		setSmoothing(0);
		//setSmoothing(0.9);
	}
	
//#ifdef OSC_GUI
//	void oscReceived(ofxOscMessage m)
//	{						 
//	}
//	
//	void oscSend()
//	{		
//	}	
//#endif	
};
