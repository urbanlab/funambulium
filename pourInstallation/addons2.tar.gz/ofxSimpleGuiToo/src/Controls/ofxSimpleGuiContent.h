#pragma once

#include "ofxSimpleGuiControl.h"


class ofxSimpleGuiContent  : public ofxSimpleGuiControl {
public:
	float			fixwidth;
	float			fixheight;
	ofBaseDraws		*content;

	ofxSimpleGuiContent(string name, ofBaseDraws& content, float fixwidth=250.0, std::string oscName = std::string());
	void setup();
	void draw(float x, float y);
	
#ifdef OSC_GUI
	void oscReceived(ofxOscMessage m);
	void oscSend();	
#endif		
};
