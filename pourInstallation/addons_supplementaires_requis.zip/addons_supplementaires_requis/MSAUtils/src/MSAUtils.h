/***********************************************************************
 
 Copyright (c) 2008, 2009, 2010, Memo Akten, www.memo.tv
 *** The Mega Super Awesome Visuals Company ***
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of  Visuals nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ***********************************************************************/

#pragma once

#include "MSACore.h"

namespace MSA {
	
	void clear();
	
	void drawFPS();
	void drawFPS(int x, int y);
	void drawFPS(int color);
	void drawFPSBar(int fpsMult=4);
	
	void dumpFPS(float seconds);
	
	void hideCursor();
	void showCursor();
	
	void setMouseCursor(bool forceOn = false);
	
	void createDir(string fullpath);
	
	void setDataPathToBundle();
	
	void restoreDataPath();
	
	string padWithZero(float num, float precision=0);
	
	string secondsToString(float secs);
	
	int showDialog(string message, string info, int style = 0);
	
	
	/***************************************************************/
	
//	struct Parameter {
//		float current;
//		float target;
//		float lerpSpeed;
//		
//		Parameter() {
//			lerpSpeed = 0.1;
//		}
//		
//		void setCurrent(float f) {
//			current = f;
//		}
//		
//		void setTarget(float f) {
//			target = f;
//		}
//		
//		void set(float f) {
//			current = target = f;
//		}
//		
//		void setSpeed(float f) {
//			lerpSpeed = f;
//		}
//		
//		void snapToTarget() {
//			current = target;
//		}
//		
//		void update(float thresh = 0) { //0.001f) {
//			float diff = target - current;
//			diff *= lerpSpeed;
//			if(thresh == 0) {
//				current += diff;
//			} else {
//				if(current!=0) {		// avoid divide by zero
//					if(fabs(diff/current) > thresh) current += diff;	// if change is bigger than % then lerp
//				} else {				// if current is zero
//					if(target !=0 && fabs(diff/target) > thresh) current += diff;	// if change is bigger than % then lerp
//				}
//			}
//		}
//		
//	};
	
}



