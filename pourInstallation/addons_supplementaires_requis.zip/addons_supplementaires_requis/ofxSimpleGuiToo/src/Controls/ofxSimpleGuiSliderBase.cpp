/*
 *  ofxSimpleGuiSliderbase.cpp
 *  MSA demo
 *
 *  Created by Mehmet Akten on 18/08/2010.
 *  Copyright 2010 MSA Visuals Ltd. All rights reserved.
 *
 */
#include "ofxSimpleGuiSliderBase.h"

typedef ofxSimpleGuiSliderBase<float> ofxSimpleGuiSliderBaseFloat;
typedef ofxSimpleGuiSliderBase<int> ofxSimpleGuiSliderBaseInt;
