#pragma once

#include "ofxSimpleGuiControl.h"

#include "ofxSimpleGuiSliderBase.h"


class ofxSimpleGuiSliderInt : public ofxSimpleGuiSliderBase<int> {
	
public:
	ofxSimpleGuiSliderInt(string name, int &value, int min, int max, std::string oscName) : ofxSimpleGuiSliderBase<int>(name, value, min, max, oscName) {
		controlType = "SliderInt";
		setIncrement(1);
	}

#ifdef OSC_GUI
//	void oscReceived(ofxOscMessage m)
//	{
//		//ofxSimpleGuiControl::oscReceived(m);
//		if(oscControlName == m.getAddress())
//		{
//			int temp = m.getArgAsInt32(0);
//			
//			if(temp>=min && temp<=max)
//			{
//				targetValue = (int)temp;
//				oldValue = *value;	// save oldValue (so the draw doesn't update target but uses it)
//			}
//		}
//	}
//	void oscSend()
//	{		
//	}	
#endif	
};
